/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.CadastroEmpresaMain;
import Main.CadastroPessoasMain;
import Model.BD;
import Model.Empresas;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class PrincipalController implements Initializable {

   @FXML private Button btce;
   @FXML private Button btcp;
   @FXML private Button btlp;
   @FXML private Button btle;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        btce.setOnMouseClicked((MouseEvent e) ->{
            CadastroEmpresaMain CadastroEmpresaMain = new CadastroEmpresaMain();
            
            try {
                CadastroEmpresaMain.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        });
        btcp.setOnMouseClicked((MouseEvent e)->{
            CadastroPessoasMain CadastroPessoasMain = new CadastroPessoasMain();
            
            try {
                CadastroPessoasMain.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        });
        
        btlp.setOnMouseClicked((MouseEvent e)->{
            try{
                     for(int x = 0; x <BD.getListadePessoas().size();x++){
                        BD.getListadePessoas().get(x).MostrarPessoas();
            }
            }
                     catch(Exception ee){
                             ee.printStackTrace();
                             }
        });
        btle.setOnMouseClicked((MouseEvent e)->{
            try{
              for(int x = 0; x <BD.getListadeEmpresas().size();x++){
                        BD.getListadeEmpresas().get(x).MostrarEmpresas();
            }
            }
                     catch(Exception ee){
                             ee.printStackTrace();
                             }
        });
        
        btce.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
            CadastroEmpresaMain CadastroEmpresaMain = new CadastroEmpresaMain();
            
            try {
                CadastroEmpresaMain.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
     });          btcp.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){    
        
                    CadastroPessoasMain CadastroPessoasMain = new CadastroPessoasMain();
            
            try {
                CadastroPessoasMain.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(PrincipalController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }   
        }); btle.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
            try{
              for(int x = 0; x <BD.getListadeEmpresas().size();x++){
                        BD.getListadeEmpresas().get(x).MostrarEmpresas();
            }
            }
                     catch(Exception ee){
                             ee.printStackTrace();
                 }
            }
        });  btlp.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
             try{
              for(int x = 0; x <BD.getListadeEmpresas().size();x++){
                        BD.getListadeEmpresas().get(x).MostrarEmpresas();
            }
            }
                     catch(Exception ee){
                             ee.printStackTrace();
                             }
            }
        });       
     
     }
}

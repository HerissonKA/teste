/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.CadastroEmpresaMain;
import Main.CadastroPessoasMain;
import Model.BD;
import Model.Empresas;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CadastroEmpresaController implements Initializable {

   @FXML private Button btcan;
   @FXML private Button btcad;
   @FXML private TextField tfnome;
   @FXML private TextField tfcnpj;
   @FXML private TextField tfcpf;
   @FXML private TextField tfend;
   @FXML private TextField tfnum;
   @FXML private TextField tfcid;
   @FXML private TextField tfest;
   
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        btcan.setOnMouseClicked((MouseEvent e)->{
            CadastroEmpresaMain.getStage().close();
        });
              btcad.setOnMouseClicked((MouseEvent e)->{
                  try{
                      Empresas emp1 = new Empresas();
                      emp1.setNome(tfnome.getText());
                      emp1.setCnpj(tfcnpj.getText());
                      emp1.setCpf(tfcpf.getText());
                      emp1.setEnd(tfend.getText());
                      emp1.setNum(tfnum.getText());
                      emp1.setCid(tfcid.getText());
                      emp1.setEst(tfest.getText());
                      BD.getListadeEmpresas().add(emp1);
                      CadastroEmpresaMain.getStage().close();
                      Alert Confirmaremp = new Alert(Alert.AlertType.CONFIRMATION);
                      Confirmaremp.setHeaderText("Cadastro da empresa realizado com sucesso!!");
                      Confirmaremp.show();
                      
                  }
                  catch(Exception ee){
                      ee.printStackTrace();
                  }
              });
             btcan.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
                 CadastroEmpresaMain.getStage().close();
            }        
       });
          btcad.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){   
                 try{
                      Empresas emp1 = new Empresas();
                      emp1.setNome(tfnome.getText());
                      emp1.setCnpj(tfcnpj.getText());
                      emp1.setCpf(tfcpf.getText());
                      emp1.setEnd(tfend.getText());
                      emp1.setNum(tfnum.getText());
                      emp1.setCid(tfcid.getText());
                      emp1.setEst(tfest.getText());
                      BD.getListadeEmpresas().add(emp1);
                      CadastroEmpresaMain.getStage().close();
                      Alert Confirmaremp = new Alert(Alert.AlertType.CONFIRMATION);
                      Confirmaremp.setHeaderText("Cadastro da empresa realizado com sucesso!!");
                      Confirmaremp.show();
                      
                  }
                  catch(Exception ee){
                      ee.printStackTrace();
                  }
            }
        });
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.CadastroPessoasMain;
import Model.BD;
import Model.Pessoas;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;


public class CadastroPessoasController implements Initializable {
@FXML private Button btcan;
@FXML private Button btcad;
@FXML private TextField tfnome;
@FXML private TextField tfsobrenome;
@FXML private TextField tfrg;
@FXML private TextField tfcpf;
@FXML private TextField tfemail;
@FXML private TextField tfend;
@FXML private TextField tfnumero;
@FXML private TextField tfcidade;
@FXML private TextField tfest;



    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btcan.setOnMouseClicked((MouseEvent e)->{
          CadastroPessoasMain.getStage().close();
            
        });
        
        btcad.setOnMouseClicked((MouseEvent e)->{
          try{
          Pessoas pes = new Pessoas();
          pes.setNome(tfnome.getText());
          pes.setSobrenome(tfsobrenome.getText());
          pes.setRg(tfrg.getText());
          pes.setCpf(tfcpf.getText());
          pes.setEmail(tfemail.getText());
          pes.setCid(tfcidade.getText());
          pes.setEnd(tfend.getText());
          pes.setNum(tfnumero.getText());
          pes.setEst(tfest.getText());
          BD.getListadePessoas().add(pes);
          CadastroPessoasMain.getStage().close();
          Alert deubom = new Alert(Alert.AlertType.CONFIRMATION);
          deubom.setHeaderText("Cadastro Realizado com Sucesso!!");
          deubom.show();
          }
          catch(Exception ee){
              ee.printStackTrace();
              
          }
          
          });              
            btcad.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
                  try{
          Pessoas pes = new Pessoas();
          pes.setNome(tfnome.getText());
          pes.setSobrenome(tfsobrenome.getText());
          pes.setRg(tfrg.getText());
          pes.setCpf(tfcpf.getText());
          pes.setEmail(tfemail.getText());
          pes.setCid(tfcidade.getText());
          pes.setEnd(tfend.getText());
          pes.setNum(tfnumero.getText());
          pes.setEst(tfest.getText());
          BD.getListadePessoas().add(pes);
          CadastroPessoasMain.getStage().close();
          Alert deubom = new Alert(Alert.AlertType.CONFIRMATION);
          deubom.setHeaderText("Cadastro Realizado com Sucesso!!");
          deubom.show();
          }
          catch(Exception ee){
              ee.printStackTrace();
              
          }
        }
        
     });
            btcan.setOnKeyPressed((KeyEvent evt)->{
            if(evt.getCode() == KeyCode.ENTER){
                          CadastroPessoasMain.getStage().close();
                }
    
          });
    }
}

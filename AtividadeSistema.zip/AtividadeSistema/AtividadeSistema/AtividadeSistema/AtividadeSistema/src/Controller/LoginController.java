/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.LoginMain;
import Main.PrincipalMain;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


/**
 *
 * @author Aluno
 */
public class LoginController implements Initializable {
   
    @FXML private TextField tfuser;
    @FXML private PasswordField pfuser;
    @FXML private Button btsair;
    @FXML private Button btentrar;
     
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btentrar.setOnMouseClicked((MouseEvent e) ->{
            if(tfuser.getText().equals("user")&&
               pfuser.getText().equals("user123")){
                PrincipalMain PrincipalMain = new PrincipalMain();
                LoginMain.getStage().close();
                try {
                    PrincipalMain.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                  
                
            }
                else{
                  Alert erro = new Alert(Alert.AlertType.ERROR);
                  erro.setHeaderText("Usuario e/ou senha invalidos! Tente novamente");
                  erro.show();
                           
                        
                }
        
                
            
        });
        btsair.setOnMouseClicked(new EventHandler<MouseEvent>(){
                 public void handle(MouseEvent e) {
                    LoginMain.getStage().close();
        }    
});
        pfuser.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode() == KeyCode.ENTER){
               if(tfuser.getText().equals("user")&&
               pfuser.getText().equals("user123")){
                PrincipalMain PrincipalMain = new PrincipalMain();
                LoginMain.getStage().close();
                try {
                    PrincipalMain.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                  
                
            }
                else{
                  Alert erro = new Alert(Alert.AlertType.ERROR);
                  erro.setHeaderText("Usuario e/ou senha invalidos! Tente novamente");
                  erro.show();
                           
                        
                }
               
           } 
        });
                btentrar.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode() == KeyCode.ENTER){
               if(tfuser.getText().equals("user")&&
               pfuser.getText().equals("user123")){
                PrincipalMain PrincipalMain = new PrincipalMain();
                LoginMain.getStage().close();
                try {
                    PrincipalMain.start(new Stage());
                } catch (Exception ex) {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
                  
                
            }
                else{
                  Alert erro = new Alert(Alert.AlertType.ERROR);
                  erro.setHeaderText("Usuario e/ou senha invalidos! Tente novamente");
                  erro.show();
                           
                        
                }
               
           } 
        }); btsair.setOnKeyPressed((KeyEvent evt)->{
           if(evt.getCode() == KeyCode.ENTER){
                    LoginMain.getStage().close();
                } 
           });
        
        }    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Main.CadastroPessoasMain;
import javafx.scene.control.Alert;

/**
 *
 * @author samuel
 */
public class Pessoas {
    private String Nome;
    private String Sobrenome;
    private String rg;
    private String cpf;
    private String email;
    private String end;
    private String cid;
    private String num;
    private String est;


    public String getNome() {
        return Nome;
    }


    public void setNome(String Nome) {
        this.Nome = Nome;
    }


    public String getSobrenome() {
        return Sobrenome;
    }


    public void setSobrenome(String Sobrenome) {
        this.Sobrenome = Sobrenome;
    }

    public String getRg() {
        return rg;
    }


    public void setRg(String rg) {
        this.rg = rg;
    }


    public String getCpf() {
        return cpf;
    }


    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    public String getEnd() {
        return end;
    }


    public void setEnd(String end) {
        this.end = end;
    }


    public String getCid() {
        return cid;
    }


    public void setCid(String cid) {
        this.cid = cid;
    }


    public String getNum() {
        return num;
    }


    public void setNum(String num) {
        this.num = num;
    }


    public String getEst() {
        return est;
    }


    public void setEst(String est) {
        this.est = est;
    }
    
    public void MostrarPessoas(){
        System.out.println("----------------------------------");
       System.out.println("Nome: "+getNome()+" "+getSobrenome());
        System.out.println("RG: "+getRg());
        System.out.println("CPF: "+getCpf());
        System.out.println("Email: "+getEmail());
        System.out.println("Endereco: "+getEnd());
        System.out.println("Cidade: "+getCid());
        System.out.println("Número Endereco: "+getNum());
        System.out.println("Estado: "+getEst());
        System.out.println("----------------------------------");
    
}

}

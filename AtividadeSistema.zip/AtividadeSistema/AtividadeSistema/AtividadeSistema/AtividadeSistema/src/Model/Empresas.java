/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author samuel
 */
public class Empresas {
 
    private String Nome;
    private String cnpj;
    private String cpf;
    private String end;
    private String num;
    private String cid;
    private String est;


    public String getNome() {
        return Nome;
    }


    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    
    public String getCnpj() {
        return cnpj;
    }


    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }


    public String getCpf() {
        return cpf;
    }


    public void setCpf(String cpf) {
        this.cpf = cpf;
    }


    public String getEnd() {
        return end;
    }


    public void setEnd(String end) {
        this.end = end;
    }


    public String getNum() {
        return num;
    }


    public void setNum(String num) {
        this.num = num;
    }


    public String getCid() {
        return cid;
    }


    public void setCid(String cid) {
        this.cid = cid;
    }


    public String getEst() {
        return est;
    }


    public void setEst(String est) {
        this.est = est;
    }
    
    public void MostrarEmpresas(){
        System.out.println("----------------------");
        System.out.println("Nome: "+getNome());
        System.out.println("CNPJ: "+getCnpj());
        System.out.println("Cpf: "+getCpf());
        System.out.println("Endereco: "+getEnd());
        System.out.println("Numero: "+getNum());
        System.out.println("Cidade: "+getCid());
        System.out.println("Estado: "+getEst());
        System.out.println("----------------------");
    }
}
